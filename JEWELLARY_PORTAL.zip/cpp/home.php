<?php
include("nav.php");
// require 'config.php';
// if(!empty($_SESSION["id"])){
//   $id = $_SESSION["id"];
//   // $result = mysql_query($conn "SELECT * FROM user_l WHERE id = $id");
//   $row = mysql_fetch_assoc($result);
// }
// else{
//   header("Location: index.php");
// }
// ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="css/style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <link rel="icon" type="image/x-icon" href="image/favicon.png">
   </head>
<body>
  
  <section class="home-section" style="background: url(image/223741-bigthumbnail.jpg);background-repeat: no-repeat;
  background-size: 100% 100%;">
    <!-- <img src="image/223741-bigthumbnail.jpg" alt="" style="width: 100%; opacity: 0.8;"> -->

<div class="slideshow-container">

<div class="mySlides fade">
  
  <img src="image/banner12.jpg" style="width:100%">
  
</div>

<div class="mySlides fade">

  <img src="image/collection_bannernew.jpg" style="width:100%">
  
</div>

<div class="mySlides fade">
  
  <img src="image/private-banner.jpg" style="width:100%">
  
</div>

</div>
<br>

<div style="text-align:center">
    <span class="dot"></span> 
    <span class="dot"></span> 
    <span class="dot"></span> 
</div>

<div class="MainCard">
    <div class="row">
        <div class="column">
            <div class="card">
                <img src="Photos/Gold/Necklaces/1.jpg" alt="gold image" style="border: solid 2px;">
                <h3>GOLD RATE :</h3>
                <h1><span id="gol"></span>62,200.00 Rs</h1>
            </div>
        </div>
        <div class="column">
            <div class="card">
                <img src="Photos/Silver/Pendants/1.jpg" alt="silver image"style="border: solid 2px;">
                <h3>SILVER RATE :</h3>
                <h1>$<span id="sliver"></span>71,600.00 Rs</h1>
            </div>
        </div>
        <div class="column">
            <div class="card">
                <img src="Photos/Silver/Lady Rings/1.jpg" alt="platinum image"style="border: solid 2px;">
                <h3>PLATINUM RATE :</h3>
                <h1><span id="platinum"></span>27,520 Rs</h1>
            </div>
        </div>
        
    </div>
</div>
<script src="js/rate.js"></script>
<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>
<?php
include("footer.php");
?>
  </section>
 
</body>
</html>
