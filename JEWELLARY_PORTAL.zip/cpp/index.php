<?php
require 'config.php';
if(isset($_POST['login'])){

   $email =$_POST['email'];
   $pass = $_POST['password'];

   $select = mysqli_query($conn, "SELECT * FROM `User_l` WHERE email = '$email' AND pas = '$pass'") or die('query failed');
   $row = mysqli_fetch_assoc($select);
    
   if(mysqli_num_rows($select) > 0){
      if($pass == $row["pas"]){
          $_SESSION["login"] = true;
          $_SESSION["id"] = $row["id"];
          header("Location: home.php");
      }
      else{
        echo "<script>alert('Username or password is incorrect')</script>";
      }
   }else{
    echo "<script>alert('Username or password is incorrect');
    window.location.href='index.php';</script>";
   }
   if(isset($_POST['logout'])){
   $_SESSION = [];
   session_unset();
   session_destroy();
   header("Location: index.php");
   }
}

if(isset($_POST['submit'])){

  $name =$_POST['name'];
  $email =$_POST['email'];
  $pass =$_POST['password'];
  $cpass =$_POST['cpassword'];

  $select = mysqli_query($conn, "SELECT * FROM `User_l` WHERE email = '$email' AND pas = '$pass'") or die('query failed');

  if(mysqli_num_rows($select) > 0){
     echo "<script> alert('User already exists');</script>";
  }else{
    if($pass == $cpass){
    mysqli_query($conn, "INSERT INTO `User_l`(name, email, pas) VALUES('$name', '$email', '$pass')") or die('query failed');
    mysqli_query($conn, "INSERT INTO `a_users`(first_name, email, password) VALUES('$name', '$email', '$pass')") or die('query failed');
    $message[] = 'registered successfully!';
     header('location:index.php');
    }
    else{
      echo "<script>alert('password does not match');</script>";
    }
  }

}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="css/loginU.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <link rel="icon" type="image/x-icon" href="image/favicon.png">
   </head>
<body>
<?php
if(isset($message)){
   foreach($message as $message){
      echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
   }
}
?>
  <section class="home-section" >
    <div class="container">
        <div class="box"></div>
        <div class="container-forms">
          <div class="container-info">
            <div class="info-item">
              <div class="table">
                <div class="table-cell">
                  <p>
                    Have an account?
                  </p>
                  <div class="btn">
                    Log in
                  </div>
                </div>
              </div>
            </div>
            <div class="info-item">
              <div class="table">
                <div class="table-cell">
                  <p>
                    Don't have an account? 
                  </p>
                  <div class="btn">
                    Sign up
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="container-form">
            <div class="form-item log-in">
              <div class="table">
                <div class="table-cell">
                  <form action="" method="post">
                  <input name="email" placeholder="Username" type="text" required=""/>
                  <input name="password" placeholder="Password" type="Password" required=""/>
                  <input type="submit" name="login" class="btn" value="login now">
                  <a href="loginA.php" class="btn">Admin Login</a>
                  </form>
                </div>
              </div>
            </div>

            
            <div class="form-item sign-up">
              <div class="table">
                <div class="table-cell">
                <form action="" method="post">
      <input type="text" name="name" required placeholder="enter username" required="">
      <input type="email" name="email" required placeholder="enter email" required="">
      <input type="password" name="password" required placeholder="enter password" required="">
      <input type="password" name="cpassword" required placeholder="confirm password" required="">
      <input type="submit" name="submit" class="btn" value="register now">
   </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php
if(isset($message)){
   foreach($message as $message){
      echo '<div class="message" onclick="this.remove();">'.$message.'</div>';
   }
}
?>
        <!-- <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>  -->
        <script  src="js/loginU.js"></script>
  </section>
  <script>
  let sidebar = document.querySelector(".sidebar");
  let closeBtn = document.querySelector("#btn");
  let searchBtn = document.querySelector(".bx-search");

  closeBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("open");
    menuBtnChange();//calling the function(optional)
  });

  searchBtn.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
    sidebar.classList.toggle("open");
    menuBtnChange(); //calling the function(optional)
  });

  // following are the code to change sidebar button(optional)
  function menuBtnChange() {
   if(sidebar.classList.contains("open")){
     closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
   }else {
     closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
   }
  }
  </script>

</body>
</html>
