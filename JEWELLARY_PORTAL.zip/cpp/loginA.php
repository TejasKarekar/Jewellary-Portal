<?php
require("config.php")
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="css/loginA.css">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <link rel="icon" type="image/x-icon" href="image/favicon.png">
</head>
<body>
  <section class="home-section">
<!-- partial:index.partial.html -->
<div class="login-box">
  <h2>Login</h2>
  <form method="post">
    <div class="user-box">
      <input type="text" name="UserName" required="">
      <label>Username</label>
    </div>
    <div class="user-box">
      <input type="password" id="password" name="UserPassword" required="">
      <button type="button" id="eyeball">
        <div class="eye"></div>
      </button>
      <div id="beam"></div>
      <label>Password</label>
    </div>
  <div class="button">
    <input type="submit" value="submit" name="Login">
    <a href="index.php">User Login</a>
    </div>  
    
  </form>
</div>
<!-- partial -->
</section>

<?php

if(isset($_POST['Login'])){
    $UserName = $_POST['UserName'];
    $UserPassword = $_POST['UserPassword'];
    $UserPassword = md5($UserPassword);

    $query="SELECT * FROM `admin_l` WHERE `UserName`='$_POST[UserName]' AND `Password`='$_POST[UserPassword]'";
    $result=mysqli_query($conn,$query);
    if(mysqli_num_rows($result)==1)
    {
        echo "<script>alert('WELLCOME ADMIN !!!');
        window.location.href='admin_panel/ADMIN.php';</script>";
    }
    else
    {
        echo "<script>alert('Username or password is incorrect');
        window.location.href='loginA.php';</script>";
    }
}
?>
<script  src="js/loginA.js"></script>
</body>
</html>
