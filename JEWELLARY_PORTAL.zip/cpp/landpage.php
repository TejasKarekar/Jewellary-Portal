<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=ABeeZee&family=Noto+Serif+JP:wght@500;600;700;900&display=swap"
            rel="stylesheet">
        <link rel="stylesheet" href="css/landpage.css">
        <link rel="icon" type="image/x-icon" href="image/favicon.png">
    </head>

    <body>
        <div class="container">
            <!-- navigation -->
            <nav>
                <!-- logo  -->
                <div class="logo">
                    <a href="landpage.php">
                    <!-- <img src="image/jewellary-logo2.jpg" alt="logo" style="width:30px ">  -->
                    <h3>Jewellary Point</h3>
                    </a>
                </div>
                <!--end logo  -->

                <!-- menu list  -->
                <div class="menu">
                    <ul>
                        <li><a href="index.php">Categories</a></li>
                        <li><a href="index.php">About</a></li>
                        <li><a href="index.php">Shop</a></li>
                        <li><a href="index.php">Contact</a></li>
                        <li><a href="index.php">Login/Register</a></li>
                    </ul>
                </div>
                <!--end menu list  -->
                

                <!-- icons -->
                <div class="icons">
                    <img class="search" src="img/shearch.png" alt="search">
                    <img class="shop" src="img/shop.png" alt="shop">
                    <img class="menu-icon" src="img/menu.png" alt="menu-icon">
                </div>
                <!--end icons -->
            </nav>
            <!--END navigation -->
            <!-- header  -->
            <div class="header">
                <div class="row">

                    <!-- first col  -->
                    <div class="col">
                        <!-- img  -->
                        <div class="ring-img">
                            
                            <img class="bg-delete" src="img/Header Image1.png" alt="gold-ring">
                        </div>
                        <!-- title  -->
                        <div class="big-title">
                            <h1>
                                Jewellery tells a great story
                            </h1>
                        </div>
                        <!-- ring type  -->
                        <div class="type-ring">
                            <div class="type">
                                <h2>Gold</h2>
                                <p>Her provision acuteness had two why intention. </p>
                            </div>
                            <div class="type">
                                <h2>SILVER</h2>
                                <p>Her provision acuteness had two why intention. </p>
                            </div>
                        </div>
                    </div>

                    <!-- second col  -->
                    <div class="col">
                        <div class="story">
                            <h2>Our Story</h2>
                            <p>modern jewelry is made of gold, silver, or platinum, often 
                                with precious or semiprecious stones, it evolved from shells,
                                animal teeth, and other items used as body decoration in 
                                prehistoric times.
                            </p>
                        </div>
                        <div class="ring-img">
                        
                            <img class="bg-delete" src="img/header image2.png" 
                            alt="gold-ring">
                        </div>
                    </div>                
                </div>
                <!-- social media icons -->
                
                    
            </div>
            <!--end header  -->
            <!-- catalogs  -->
            <div class="catalog">
                <!-- first catalog -->
                <div class="row">
                    <!-- the image  -->
                    <div class="img">
                        <img class="bg-delete" src="img/bracelet.png" alt="bracelet">
                    </div>
                    <!-- content  -->
                    <div class="content">
                        <h2>Gold Woven Chain Bracelet in Black</h2>
                        <p>This bracelet features a 5MM Stainless Steel 
                            chain with Nylon cord braiding. Each bracelet includes 
                            a polishing pad and a cotton jewelry pouch. Proudly made 
                            by hand in Atlanta, GA.
                        </p>
                        <div class="size">
                            <p>Size</p>
                            <span> S </span>
                            <span> M </span>
                            <span> L </span>
                        </div>
                        <div class="buy-btn">
                            <button class="btn-card">Add to card</button>
                            <p class="price">
                                549.29
                            </p>
                        </div>
                    </div>
                </div>
                <!-- second catalog -->
                <div class="row">
                    <div class="content">
                        <h2>Gold Black Coral Ring</h2>
                        <p>
                            A 14K yellow gold ring Two Hawaiian Black Coral inlaid strips, 
                            14.5x2mm Ring sizes 4-8 Contact us for additional ring sizes To our 
                            valued International Customers, an extra CITES charge will 
                            be added to your order. 
                        </p>
                        <div class="size">
                            <p>Size</p>
                            <span> S </span>
                            <span> M </span>
                            <span> L </span>
                        </div>
                        <div class="buy-btn">
                            <button class="btn-card">Add to card</button>
                            <p class="price">
                                320.99
                            </p>
                        </div>
                    </div>
                    <div class="img">
                        <img class="bg-delete" src="img/black ring.png" alt="black ring">
                    </div>      
                </div>
            </div>

            <!-- collections  -->
            <div class="collection">
                <!-- item1  -->
                <div class="row">
                    <div class="img">
                        <img src="img/best ring.png" alt="best ring">
                    </div>
                    <div class="content">
                        <h2> Jewellary point’s best Collections</h2>
                        <h3>Comfort</h3>
                        <p> We will reach out to you for the current cost of this permit. 
                            Please contact us for more information. Maui Divers Jewelry 
                            offers extended sizing which may be subject to an additional cost. 
                            Any subsequent resizes after purchase will incur an additional charge. 
                            Please note some styles cannot be resized due to their design.
                        </p>
                    </div>
                </div>

                <!-- item2  -->
                <div class="row">
                    <div class="content">
                        <h3>100% Gold</h3>
                        <p> 
                            Gold chains were a sign of service to 
                            the supreme beings of a particular religion 
                            in the past. Nowadays, they are symbols of wealth 
                            and class. Rap artists were most likely the ones who 
                            brought the custom of wearing gold chains to modern men's 
                            everyday life. There are a few reasons why do men wear gold chains.
                        </p>
                    </div>
                    <div class="img">
                        <img src="img/gold.png" alt="gold">
                    </div>
                    
                </div>

                <!-- item3  -->
                <div class="row">
                    <div class="img">
                        <img src="img/trendy.png" alt="gold">
                    </div>
                    <div class="content">
                        <h3>Trendy</h3>
                        <p> 
                            A collection of hammered gold discs swing 
                            from the top and bottom of a shimmery gold hoop, 
                            creating a noisy fringe. Earring attaches to a standard 
                            fishhook fitting. Sold as one pair of earrings.Other hoop 
                            designs do not complete the circle, but penetrate through 
                            the ear in a post, using the same attachment techniques that 
                            apply to stud earrings.
                        </p>
                        <button class="btn-card" >
                            GO TO SHOP
                        </button>
                    </div>
                </div>
            </div>

            
            <!-- join-us section -->
            <div class="join-us">
                <h2>
                    Join Jewellary point’s Family
                </h2>
                <form>
                    <input type="email" name="email" placeholder="Enter your email">
                    <button class="btn-card input">JOIN FAMILY</button>
                </form>
            </div>
            <!--end join-us section -->

            <!-- blog section  -->
            <div class="blog">
                <h2>Our Blogs</h2>
                <div class="blog-row">
                    <!-- item1  -->
                    <div class="col">
                        <div class="img">
                            <img src="img/blog-1.png">
                        </div>
                        <div class="content">
                            <h3>For Beauty</h3>
                            <p>Offending belonging promotion provision an 
                                be oh consulted ourselves it.
                            </p>
                        </div>
                    </div>
                    <!-- item2  -->
                    <div class="col">
                        <div class="img">
                            <img src="img/blog-1.png">
                        </div>
                        <div class="content">
                            <h3>Product Quality</h3>
                            <p>Blessing welcomed ladyship she met humoured 
                                sir breeding her. Six curiosity day necessary.
                            </p>
                        </div>
                    </div>
                    <!-- item3  -->
                    <div class="col">
                        <div class="img">
                            <img src="img/blog-3.png" alt="">
                        </div>
                        <div class="content">
                            <h3>For Comfort</h3>
                            <p>Warmly little before cousin sussex entire men set. 
                                Blessing it ladyship on sensible judgment.
                            </p>
                        </div>
                    </div>
                </div>
            </div>


        <!-- copyright section  -->
        <div class="copyright">
            <p>
                Copyright <span class="date"></span> Jewellary point.com, All rights reserved.
            </p>
        </div>

        <script src="js/landpage.js"></script>
    </body>

</html>