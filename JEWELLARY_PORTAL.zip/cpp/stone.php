<?php
require('config.php')
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="css/stone.css">
    <?php require 'nav.php' ?>
    <link rel="icon" type="image/x-icon" href="image/favicon.png">
</head>

<body>

<section class="home-section">
<?php
    if(isset($_POST['reg'])){
       button(); 
    }
    function button()
        {
        $zodiac = $_POST['zodiac'];
            switch ($zodiac){
                case "Taurus":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Opal is the perfect stone for Taurus navtives - </h2></center><center><img width=500px; src=image/opal.jpg></center>'
                        );</script>";
                break;
                case "Gemini":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Emerald is the perfect stone for Gemini navtives - </h2></center><center><img width=500px; src=image/emerald.jpg></center>'
                        );</script>";
                break;
                case "Leo":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Ruby is the perfect stone for leo navtives - </h2></center><center><img width=500px; src=image/ruby.jpg></center>'
                        );</script>";
                break;
                case "Cancer":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Pearl is the perfect stone for Cancer navtives - </h2></center><center><img width=500px; src=image/pearl.jpg></center>'
                        );</script>";
                break;
                case "Virgo":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Opal is the perfect stone for Virgo navtives - </h2></center><center><img width=500px; src=image/opal.jpg></center>'
                        );</script>";
                break;
                case "Libra":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Opal is the perfect stone for Libra navtives - </h2></center><center><img width=500px; src=image/opal.jpg></center>'
                        );</script>";
                break;
                case "Scorpio":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Red coral is the perfect stone for Scorpio navtives - </h2></center><center><img width=400px; src=image/red_coral.jpg></center>'
                        );</script>";
                break;
                case "Sagittarius":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Yellow Sapphire is the perfect stone for Sagittarius navtives - </h2></center><center><img width=500px; src=image/yellow_sapphire.jpg></center>'
                        );</script>";
                break;
                case "Caoricorn":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Blue Sapphire is the perfect stone for Capricorn navtives - </h2></center><center><img width=500px; src=image/blue_sapphire.jpg></center>'
                        );</script>";
                break;
                case "Aquirius":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Blue Sapphire is the perfect stone for Aquarius navtives - </h2></center><center><img width=500px; src=image/blue_sapphire.jpg></center>'
                        );</script>";
                break;
                case "Pisces":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Yellow Sapphire is the perfect stone for Pisces navtives - </h2></center><center><img width=500px; src=image/yellow_sapphire.jpg></center>'
                        );</script>";
                break;
                case "Aries":
                    echo "<script>document.write(
                        '<br><br><br><br><center><h2> - Red coral is the perfect stone for Aries navtives - </h2></center><center><img width=400px; src=image/red_coral.jpg></center>'
                        );</script>";
                break;
            }
        }
    ?>
    <div class="wrapper" style="background-image: url('tech.jpg');">
        <div class="inner">
            <div class="image-holder">
                <img src="image/Gem.png" alt="Image" srcset="">
            </div>
            <form action="" method="post">
                <h3>Registration Form</h3>
                <div class="form-group">
                    <input type="text" placeholder="First Name" class="form-control" name="firstname">
                    <input type="text" placeholder="Last Name" class="form-control" name="lastname">
                </div>
                <div class="form-wrapper">
                    <input type="date" placeholder="Date OF Birth" class="form-control" name="dob">

                </div>
                <div class="form-wrapper">
                    <input type="text" placeholder="Email Address" class="form-control" name="email">

                </div>
                <div class="form-wrapper">
                    <select id="gender" class="form-control" name="gender">
                        <option value="" disabled selected>Gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="form-wrapper">
                    <input type="text" placeholder="City" class="form-control" name="city">

                </div>
                <div class="form-wrapper">
                <select name="zodiac" id="ras" style="height:25px;width:300px;font-size:14pt; ">
            <option value="Taurus">Taurus</option>
            <option value="Gemini">Gemini</option>
            <option value="Leo">Leo</option>
            <option value="Cancer">Cancer</option>
            <option value="Virgo">Virgo</option>
            <option value="Libra">Libra</option>
            <option value="Scorpio">Scorpio</option>
            <option value="Sagittarius">Sagittarius</option>
            <option value="Caoricorn">Caoricorn</option>
            <option value="Aquirius">Aquirius</option>
            <option value="Pisces">Pisces</option>
            <option value="Aries">Aries</option>
          </select>

                </div>
                <button type="submit"name="reg" id="btn">submit</button>
            </form>
        </div>
    </div>
    
    <?php
	
	if(isset($_POST['reg']) || isset($gender)){
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$dob = $_POST['dob'];
		$email = $_POST['email'];
		$gender = $_POST['gender'];
		$city = $_POST['city'];
		$zodiac = $_POST['zodiac'];
		
		if($conn->connect_error)
		{
			echo "Connection failed: ". $conn->connect_error;
		}
		else
		{
			$stmt = $conn->prepare("INSERT INTO birthstone(firstname, lastname, dob, email, gender, city, zodiac) VALUES (?,?,?,?,?,?,?)");
			$stmt->bind_param('sssssss', $firstname, $lastname, $dob, $email, $gender, $city, $zodiac);
			$stmt->execute();
			echo "<script>alert('click ok to see your birthstone !!!');</script>";
			$stmt->close();
			$conn->close();
			
		}
	}
	?>

</section>
</body>

</html>