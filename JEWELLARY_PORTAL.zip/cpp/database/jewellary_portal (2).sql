-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2023 at 02:34 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jewellary_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_l`
--

CREATE TABLE `admin_l` (
  `UserName` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_l`
--

INSERT INTO `admin_l` (`UserName`, `Password`) VALUES
('PortalAdmin', 'Jewellary13');

-- --------------------------------------------------------

--
-- Table structure for table `a_cart`
--

CREATE TABLE `a_cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `variation_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `a_category`
--

CREATE TABLE `a_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_category`
--

INSERT INTO `a_category` (`category_id`, `category_name`) VALUES
(5, 'Ring'),
(7, 'pendent'),
(8, 'Bracelet'),
(9, 'Ear Ring'),
(10, 'Gold'),
(11, 'Silver'),
(12, 'Diamond');

-- --------------------------------------------------------

--
-- Table structure for table `a_orders`
--

CREATE TABLE `a_orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `delivered_to` varchar(150) NOT NULL,
  `phone_no` varchar(10) NOT NULL,
  `deliver_address` varchar(255) NOT NULL,
  `pay_method` varchar(50) NOT NULL,
  `pay_status` int(11) NOT NULL,
  `order_status` int(11) NOT NULL DEFAULT 0,
  `order_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_orders`
--

INSERT INTO `a_orders` (`order_id`, `user_id`, `delivered_to`, `phone_no`, `deliver_address`, `pay_method`, `pay_status`, `order_status`, `order_date`) VALUES
(1, 3, 'Self', '9802234675', 'Matepani-12', 'Cash', 0, 1, '2022-04-10'),
(3, 3, 'Test  Firstuser', '980098322', 'matepani-12', 'cash on delivery', 1, 0, '2022-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `a_order_details`
--

CREATE TABLE `a_order_details` (
  `detail_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `variation_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_order_details`
--

INSERT INTO `a_order_details` (`detail_id`, `order_id`, `variation_id`, `quantity`, `price`) VALUES
(1, 1, 1, 1, 500);

-- --------------------------------------------------------

--
-- Table structure for table `a_product`
--

CREATE TABLE `a_product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `uploaded_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_product`
--

INSERT INTO `a_product` (`product_id`, `product_name`, `product_desc`, `product_image`, `price`, `category_id`, `uploaded_date`) VALUES
(10, 'Ear ring', 'ledies gold ear ring', './uploads/1.jpg', 600, 5, '2023-04-29'),
(11, 'Coins', 'gold coin', './uploads/5.jpg', 400, 7, '2023-04-30'),
(12, 'neakless', 'Ledies neakless', './uploads/13.jpg', 900, 7, '2023-04-30'),
(13, 'Gold Ear ring', 'ledies gold ear ring', './uploads/8.jpg', 350, 5, '2023-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `a_product_size_variation`
--

CREATE TABLE `a_product_size_variation` (
  `variation_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `quantity_in_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_product_size_variation`
--

INSERT INTO `a_product_size_variation` (`variation_id`, `product_id`, `size_id`, `quantity_in_stock`) VALUES
(1, 1, 4, 5),
(2, 2, 3, 9),
(3, 2, 2, 3),
(6, 3, 3, 6),
(7, 4, 2, 8),
(8, 5, 4, 8),
(9, 6, 2, 10),
(10, 7, 2, 10),
(11, 10, 4, 100);

-- --------------------------------------------------------

--
-- Table structure for table `a_review`
--

CREATE TABLE `a_review` (
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `review_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_review`
--

INSERT INTO `a_review` (`review_id`, `user_id`, `product_id`, `review_desc`) VALUES
(1, 2, 2, 'Comfortable and stylish. I loved it.'),
(2, 2, 5, 'Perfect dress for summer.');

-- --------------------------------------------------------

--
-- Table structure for table `a_sizes`
--

CREATE TABLE `a_sizes` (
  `size_id` int(11) NOT NULL,
  `size_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_sizes`
--

INSERT INTO `a_sizes` (`size_id`, `size_name`) VALUES
(4, 'Free');

-- --------------------------------------------------------

--
-- Table structure for table `a_users`
--

CREATE TABLE `a_users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(150) NOT NULL,
  `contact_no` varchar(10) NOT NULL,
  `registered_at` date NOT NULL DEFAULT current_timestamp(),
  `isAdmin` int(11) NOT NULL DEFAULT 0,
  `user_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `a_users`
--

INSERT INTO `a_users` (`user_id`, `first_name`, `last_name`, `email`, `password`, `contact_no`, `registered_at`, `isAdmin`, `user_address`) VALUES
(1, 'tejas', '', 'testemail@12gmail.com', '123456789', '', '2023-05-03', 0, ''),
(17, 'tejas', '', 'tejaskarekar17@gmail.com', '12345', '', '2023-05-04', 0, ''),
(18, 'Tej', '', 'test123@gamil.com', '12345', '', '2023-05-09', 0, ''),
(19, 'suyog', '', 'suyogp@gmail.com', '123', '', '2023-05-10', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `a_wishlist`
--

CREATE TABLE `a_wishlist` (
  `wish_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `birthstone`
--

CREATE TABLE `birthstone` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `city` varchar(50) NOT NULL,
  `zodiac` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `birthstone`
--

INSERT INTO `birthstone` (`id`, `firstname`, `lastname`, `dob`, `email`, `gender`, `city`, `zodiac`) VALUES
(16, 'Tejas', 'karekar', '2003-11-22', 'tejaskarekar17@gmail.com', 'male', 'ratnagiri', 'Libra'),
(17, 'Tejas', 'karekar', '2003-11-22', 'tejaskarekar17@gmail.com', 'male', 'ratnagiri', 'Libra'),
(18, 'Tejas', 'karekar', '2003-11-22', 'tejaskarekar17@gmail.com', 'male', 'ratnagiri', 'Libra'),
(19, 'tej', 'karekar', '2003-11-22', 'test123@gamil.com', 'male', 'ratnagiri', 'Libra'),
(20, 'tej', 'karekar', '2003-11-22', 'test123@gamil.com', 'male', 'ratnagiri', 'Libra');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `price`, `image`, `quantity`) VALUES
(79, 9, 'Coins', '400', './uploads/5.jpg', 1),
(99, 0, 'Ear ring', '600', './uploads/1.jpg', 1),
(100, 0, 'Coins', '400', './uploads/5.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `First_name` varchar(20) NOT NULL,
  `Last_name` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Mobile` int(10) NOT NULL,
  `Msg` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`First_name`, `Last_name`, `Email`, `Mobile`, `Msg`) VALUES
('tejas ', 'karekar', 'tejaskarekar17@gmail', 2147483647, 'testing feedback'),
('tejas ', 'karekar', 'tkar@gmail.com', 2147483647, 'testing feedback1'),
('tej', 'karekar', 'test123@gamil.com', 2147483647, 'testing feedback');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_l`
--

CREATE TABLE `user_l` (
  `id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `pas` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_l`
--

INSERT INTO `user_l` (`id`, `name`, `email`, `pas`) VALUES
(1, 'tejas', 'testemail@12gmail.co', 123456789),
(17, 'tejas', 'tejaskarekar17@gmail', 12345),
(18, 'tejas', 'tejaskarekar17@gmail', 12345),
(19, 'Tej', 'test123@gamil.com', 12345),
(20, 'suyog', 'suyogp@gmail.com', 123);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `a_cart`
--
ALTER TABLE `a_cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD UNIQUE KEY `uc_cart` (`user_id`,`variation_id`),
  ADD KEY `variation_id` (`variation_id`);

--
-- Indexes for table `a_category`
--
ALTER TABLE `a_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `a_orders`
--
ALTER TABLE `a_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `a_order_details`
--
ALTER TABLE `a_order_details`
  ADD PRIMARY KEY (`detail_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `variation_id` (`variation_id`);

--
-- Indexes for table `a_product`
--
ALTER TABLE `a_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `a_product_size_variation`
--
ALTER TABLE `a_product_size_variation`
  ADD PRIMARY KEY (`variation_id`),
  ADD UNIQUE KEY `uc_ps` (`product_id`,`size_id`);

--
-- Indexes for table `a_review`
--
ALTER TABLE `a_review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `a_sizes`
--
ALTER TABLE `a_sizes`
  ADD PRIMARY KEY (`size_id`);

--
-- Indexes for table `a_users`
--
ALTER TABLE `a_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `a_wishlist`
--
ALTER TABLE `a_wishlist`
  ADD PRIMARY KEY (`wish_id`),
  ADD UNIQUE KEY `uc_wish` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `birthstone`
--
ALTER TABLE `birthstone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_l`
--
ALTER TABLE `user_l`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `a_cart`
--
ALTER TABLE `a_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `a_category`
--
ALTER TABLE `a_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `a_orders`
--
ALTER TABLE `a_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `a_order_details`
--
ALTER TABLE `a_order_details`
  MODIFY `detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `a_product`
--
ALTER TABLE `a_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `a_product_size_variation`
--
ALTER TABLE `a_product_size_variation`
  MODIFY `variation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `a_review`
--
ALTER TABLE `a_review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `a_sizes`
--
ALTER TABLE `a_sizes`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `a_users`
--
ALTER TABLE `a_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `a_wishlist`
--
ALTER TABLE `a_wishlist`
  MODIFY `wish_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `birthstone`
--
ALTER TABLE `birthstone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_l`
--
ALTER TABLE `user_l`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `a_cart`
--
ALTER TABLE `a_cart`
  ADD CONSTRAINT `a_cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `a_users` (`user_id`),
  ADD CONSTRAINT `a_cart_ibfk_2` FOREIGN KEY (`variation_id`) REFERENCES `a_product_size_variation` (`variation_id`);

--
-- Constraints for table `a_orders`
--
ALTER TABLE `a_orders`
  ADD CONSTRAINT `a_orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `a_users` (`user_id`);

--
-- Constraints for table `a_order_details`
--
ALTER TABLE `a_order_details`
  ADD CONSTRAINT `a_order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `a_orders` (`order_id`),
  ADD CONSTRAINT `a_order_details_ibfk_2` FOREIGN KEY (`variation_id`) REFERENCES `a_product_size_variation` (`variation_id`);

--
-- Constraints for table `a_product`
--
ALTER TABLE `a_product`
  ADD CONSTRAINT `a_product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `a_category` (`category_id`);

--
-- Constraints for table `a_review`
--
ALTER TABLE `a_review`
  ADD CONSTRAINT `a_review_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `a_users` (`user_id`),
  ADD CONSTRAINT `a_review_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `a_product` (`product_id`);

--
-- Constraints for table `a_wishlist`
--
ALTER TABLE `a_wishlist`
  ADD CONSTRAINT `a_wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `a_users` (`user_id`),
  ADD CONSTRAINT `a_wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `a_product` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
