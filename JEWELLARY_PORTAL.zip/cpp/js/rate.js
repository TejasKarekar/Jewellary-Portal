var g = document.getElementById("gold");
var s = document.getElementById("silver");
var p = document.getElementById("platinum");


var liveprice = {
    "async": true,
    "scroosDomain": true,
    "url": "https://api.coingecko.com/api/v3/simple/price?ids=gold%2Csilver%2Cplatinum&vs_currencies=inr",

    "method": "GET",
    "headers": {}
}

$.ajax(liveprice).done(function (response){
    g.innerHTML = response.gold.inr;
    s.innerHTML = response.silver.inr;
    p.innerHTML = response.platinum.inr;
    

});