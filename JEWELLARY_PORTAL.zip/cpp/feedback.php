<?php
include 'nav.php';
?>
<?php
include 'config.php';
if(isset($_POST['send'])){
$fistname = $_POST["fname"];
$lastname = $_POST["lname"];
$email = $_POST["email"];
$mobile = $_POST["mobile"];
$message = $_POST["message"];
$sql = "INSERT INTO feedback(First_name, Last_name, Email, Mobile, Msg) VALUES ('{$fistname}','{$lastname}','{$email}','{$mobile}','{$message}' )";
$result = mysqli_query($conn, $sql) or die("Query Failed!");
if(!$result)
{
    echo "<script>alert('fill all fields')</script>";
}
else{
    echo "<script>alert('Feedback send successfully')</script>";
}
}
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/feedback.css">
    <link rel="icon" type="image/x-icon" href="image/favicon.png">
</head>
<body>
<section class="home-section" >
    <div class="contact-form">
        <h1>FEEDBACK FORM</h1>
    </div>
    <div class="contact-us">
       <form method="post">
           <input type="text" name="fname" class="form-control" placeholder="Enter First Name"> <br>
           <input type="text" name="lname" class="form-control" placeholder="Enter last Name"> <br>
           <input type="email" name="email" class="form-control" placeholder="Enter Email"> <br>
           <input type="text" name="mobile" class="form-control" placeholder="Enter Mobile Number"> <br>
           <input type="text" name="message" class="form-control" placeholder="Your Feedback"> <br>
           <input type="submit" name="send" class="form-control submit" value="submit" >
       </form>
    </div>
</section>
</body>
</html>