<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        footer {
        background-color: #121315;
        color: #ffffff;
        font-size: 16px;
    }

    .copyright {
        /* padding: 0.3em 1em; */
        background-color: #25262e;
    }

    .copyright p {
        font-size: 0.9em;
        text-align: center;
    }

    </style>
</head>
<body>
<footer>
            <div class="copyright">
                <p>Copyright &copy; 2023 Jewellary Point | All Rights Reserved</p>
            </div>


        </footer>
</body>
</html>