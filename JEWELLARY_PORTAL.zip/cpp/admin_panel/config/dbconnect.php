<?php

$conn = mysqli_connect('localhost','root','','jewellary_portal') or die('connection failed');

?>