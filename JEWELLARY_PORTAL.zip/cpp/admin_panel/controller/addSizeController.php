<?php
    
    include_once "../config/dbconnect.php";
    
    if(isset($_POST['upload']))
    {
       
        $size = $_POST['size'];
       
         $insert = mysqli_query($conn,"INSERT INTO a_sizes
         (size_name)   VALUES ('$size')");
 
         if(!$insert)
         {
             echo mysqli_error($conn);
             header("Location: ../LOGIN.php?size=error");
         }
         else
         {
             echo "Records added successfully.";
             header("Location: ../LOGIN.php?size=success");
         }
     
    }
        
?>